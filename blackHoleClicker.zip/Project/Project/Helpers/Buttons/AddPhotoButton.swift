//
//  AddPhotoButton.swift
//  Project
//
//  Created by Student on 2026-03-04.
//

import SwiftUI
import PhotosUI

struct AddPhotoButton: View {
    
    // stores the selected item from the photo picker
    @State private var selectedItem: PhotosPickerItem?
    // stores the actual UIImage after it has been loaded
    @Binding public var selectedImage: UIImage?
    
    // controls navigation to the info view, public so other navs can access it
    @Binding public var showEditReceipt: Bool
    
    var body: some View {
        // upload photo button
        // binds the selected item to selectedItem
        PhotosPicker(selection: $selectedItem, matching: .images) {
            VStack {
                ExpenseButtonLabel(systemImageName: "square.and.arrow.up", description: "Upload Photo")
            }
        }
        // runs whenever selectedItem changes
        .onChange(of: selectedItem) {
            // use the new item of selected item, previous item(_) is not needed
            _, newItem in
            
            // make sure a new item exists
            if let newItem = newItem {
                Task {
                    // try to load the image data
                    if let data = try? await newItem.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        
                        // Save loaded image into state
                        selectedImage = image
                        // Trigger navigation to info view
                        showEditReceipt = true
                    }
                }
            }
        }
    }
}

#Preview {
    AddPhotoButton(selectedImage: .constant(UIImage(systemName: "bell")), showEditReceipt: .constant(true))
}
