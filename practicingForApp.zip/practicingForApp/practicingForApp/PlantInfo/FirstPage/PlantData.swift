//
//  PlantData.swift
//  practicingForApp
//
//  Created by Student on 2026-05-12.
//

import Foundation

struct PlantData {
	static let dandelionDescription = "Taraxacum species are tap-rooted, perennial, herbaceous plants, native to temperate areas of the Northern Hemisphere. The genus contains many species, which usually (or in the case of triploids, obligately) reproduce by apomixis, resulting in many local populations and endemism. In the British Isles alone, 234 microspecies (i.e. morphologically distinct clonal populations) are recognised in nine loosely defined sections.[21] A number of Taraxacum species can act as ruderals, pioneer species that rapidly colonise disturbed soil. The common dandelion (T. officinale) has been introduced over much of the temperate world, and it is especially effective at spreading along roads, cemeteries, lawns, and pastures.[22] A week or two after flowering, the dandelion's flower becomes a round seed head.[23] The bracts, specialized leaves around the flower, curve backwards. The parachute ball fully opens into a sphere,[24] and the yellow petals fall away.[25] When development is complete, the mature seeds are attached to white, fluffy \"parachutes\", which easily detach from the seed head and glide on the wind, dispersing.\n\n- Wikipedia"
	
	static let dandelionConditions = "Light: Full sun is ideal for maximum growth, flowering, and rapid reproduction, though they adapt well to partial or full shade.\n\nSoil: Rich, fertile, and well-drained soil is best, but they thrive in compacted and disturbed soils, making them highly versatile.\n\nMoisture: Moist soil is preferred to prevent premature bitterness and to promote large leaves, particularly in early spring.\n\nTemperature: They are cold-hardy, thriving in temperate zones with consistent, moderate warmth, but can survive in extreme temperatures.\n\nNutrients: They prefer soil with high humus content and high levels of nitrogen and potassium.\n\n- Wisconsin Horticulture"
	
	static let dandelionDangers = "Dandelions can cause significant economic damage as an invasive species and infestation of other crops worldwide;[59] in some jurisdictions[where?], the species T. officinale is listed as a noxious weed.[59][61] It can also be considered invasive in protected areas such as national parks. For example, Denali National Park and Preserve in Alaska lists Taraxacum officinale as the most common invasive species in the park [62] and hosts an annual \"Dandelion Demolition\" event where volunteers are trained to remove the plant from the park's roadsides.[63]\n\n- Wikipedia"
	
	static let dandelionBenefits = "With a wide range of uses, the dandelion is cultivated in sites ranging from small gardens to massive farms. It is kept as a companion plant; its taproot brings up nutrients for shallow-rooting plants. It is also known to attract pollinating insects and release ethylene gas, which helps fruit to ripen.[82]\n\n- Wikipedia"
}


