//
//  ExpenseButtons.swift
//  Project
//
//  Created by Student on 2026-03-04.
//

import SwiftUI

// all the expense buttons decorations
struct ExpenseButtonLabel: View {
    
    @State public var systemImageName: String
    @State public var description: String
        
    var body: some View {
        // the image and test for each button lavel when adding a expense
        VStack {
            Image(systemName: systemImageName)
                .resizable()
                .scaledToFit()
                .frame(height: 40)
                .padding(.vertical, 5)
            Text(description).font(.caption)
        }
    }
}
