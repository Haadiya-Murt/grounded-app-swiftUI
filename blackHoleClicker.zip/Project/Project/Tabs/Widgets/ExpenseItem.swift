//
//  ExpenseItem.swift
//  Project
//
//  Created by Student on 2026-04-15.
//

import SwiftUI

struct ExpenseItem: View {
    
    @State var receipt: Receipt
    
    var body: some View {
        // each item in the expense list
        VStack {
            HStack {
                // category name ex food
                Text(receipt.category[0])
                Spacer()
                // the report
                Text(receipt.report)
                    .padding(5)
                    .padding(.horizontal, 2)
                    .background(Color.red)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
            }
            .padding(.vertical, 5)
            HStack {
                // date
                Text(receipt.date.formatted(date: .numeric, time: .omitted))
                Spacer()
                // total price found this reduce thingy
                Text(String (receipt.amount.reduce(0, +)))
            }
            .padding(.vertical, 5)
        }
        .padding(.horizontal)
        
    }
}

#Preview {
    ExpenseItem(
        receipt: Receipt(date: .now, amount: [1,2], category: ["cat"], report: "rep", isBusiness: false, isReimbursable: false)
    )
}
