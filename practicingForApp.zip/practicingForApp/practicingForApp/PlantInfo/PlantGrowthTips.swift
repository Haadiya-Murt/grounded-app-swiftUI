//
//  PlantGrowthTips.swift
//  practicingForApp
//
//  Created by Student on 2026-05-21.
//

import SwiftUI
import SwiftData

struct PlantGrowthTips: View {
	
	// saving plants enabler
	@Environment(\.modelContext) var context
	@Environment(\.dismiss) private var dismiss
	@Query var savedPlants: [UserPlant]
	
//	// plant info
//	var spawnLocation: CGPoint?
//	@State var plantName: String = "Yanny"
//	@State var plantSpecies: String = "Dandelion"
//	@State var plantBday: Date = Date()
//	@State var careDifficulty: Int = 1
//	@Binding var selectedImage: UIImage?
	
	
	// popup stuff
	@State private var showPopup: Bool = false
	@State private var popupCategory: String = ""
	@State private var popupContent: String = ""

	
	var body: some View {
		ZStack {
			Color.mainPink
				.ignoresSafeArea()
			
			VStack {
				
				ScrollView(.vertical, showsIndicators: true) {
					Text("Keeping your plant alive")
						.font(.custom("ChakraPetch-SemiBold", size: 30))
						.foregroundStyle(.yellingYellows)
						.padding()
						.background {
							Rectangle()
								.fill(.relativelyDeeperPink)
						}
						.padding(.vertical)
					
					Text("How to pot")
						.font(.custom("JetBrainsMono-SemiBold", size: 30))
						.foregroundStyle(.yellingYellows)
						.padding()
						.background {
							Rectangle()
								.fill(.relativelyDeeperPink)
						}
						.padding(.vertical)
				}
			}
			
		}
	}
	func categoryButton(title: String, content: String) -> some View {
		Button(action: {
			popupCategory = title
			popupContent = content
			withAnimation(.easeInOut) { showPopup = true }
		}) {
			Text(title)
				.font(.custom("ChakraPetch-SemiBold", size: 25))
				.foregroundStyle(.yellingYellows)
				.padding()
				.frame(maxWidth: .infinity)
				.background(Color.relativelyDeeperPink)
		}
	}
}

#Preview {
	PlantGrowthTips()
		.modelContainer(for: UserPlant.self, inMemory: true)
}

