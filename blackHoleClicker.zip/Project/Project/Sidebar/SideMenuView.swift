//
//  SideMenuView.swift
//  Project
//
//  Created by Student on 2026-03-02.
//

import SwiftUI

struct SideMenuView: View {
    
    @Binding var isShowing : Bool
    @Binding var selectedTab : SideMenuOptionModel
    
    var body: some View {
        // zstack to stack sidebar
        ZStack {
            
            // if showing show the sidebar
            if isShowing {
                // gray out right side
                Rectangle()
                    .opacity(0.15)
                    .ignoresSafeArea()
                    .onTapGesture { isShowing.toggle() }

                // hstack to push sidebar to the left
                HStack {
                    // main top down stack
                    VStack(alignment: .leading, spacing: 32) {
                        SideMenuHeader()
                        
                        ScrollView {
                            // show every group
                            ForEach(SideMenuGroups.allCases) { group in
                                
                                HStack {
                                    Text(group.section)
                                    Spacer()
                                }
                                .foregroundStyle(.gray)
                                .font(.subheadline)
                                .padding(.horizontal)
                                .padding(.top)
                                
                                // in each group show each option
                                ForEach(group.options) { option in
                                    Button(action: {
                                        onOptionTapped(option: option)
                                    }) {
                                        SideMenuRowView(option: option, selectedOption: $selectedTab)
                                    }
                                }
                            }
                        }
                        
                        Spacer()
                    }
                    .padding()
                    .frame(width: 270, alignment: .leading)
                    .background(Color(uiColor: .systemBackground))
                    
                    Spacer()
                }
                .transition(.move(edge: .leading))
            }
        }
        .animation(.easeInOut, value: isShowing)
    }
    // when clicked set teh tab
    private func onOptionTapped(option: SideMenuOptionModel) {
        selectedTab = option
        isShowing = false
    }
}

#Preview {
    SideMenuView(isShowing: .constant(true), selectedTab: .constant(SideMenuOptionModel.home))
}
