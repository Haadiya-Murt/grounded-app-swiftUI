//
//  EditReceipt.swift
//  Project
//
//  Created by Student on 2026-03-04.
//

import SwiftUI
import SwiftData

struct EditReceiptView: View {
    
    // for receipt model
    @Environment(\.modelContext) private var context // how to access the model
    
    // TODO: just here for testing - need to make reports its own model and need to make selected report a list
    @State private var reports: [String] = ["None", "Report1", "Report2"]
    @State private var selectedReport: String = "None"
    
    // drop down for category picker and reports
    @State private var selectedCategory: String = "Other"
    // receipt values
    @State private var isBusiness: Bool = false
    @State private var isReimbursable: Bool = false
    @State private var amount: String = "0"
    @State private var date = Date()
    
    var previewImage: UIImage?
    
    // bind showing info so this tab can use it
    @Binding var showInfo: Bool
    
    var body: some View {
        
        ScrollView {
            
            VStack (alignment: .leading) {
                
                // image
                Text("Receipt")
                    .padding(.horizontal, K.Padding.horizontalTabPadding)
                    .padding(.top, K.Padding.underBackButtonPadding)
                
                HStack () {
                    Spacer()
                    // if there is an image use it else use the add image
                    if let image = previewImage {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 100)
                            .cornerRadius(3)
                    } else { // otherwise use some random image
                        // TODO: make this a button to add image
                        Image(systemName: "plus.rectangle.on.rectangle")
                            .resizable()
                            .scaledToFit()
                            .frame(height: 50)
                    }
                    Spacer()
                }
                .padding(.bottom, K.Padding.verticalWidgetPadding)
                
                // date
                VStack {
                    HStack {
                        Spacer()
                        // use the data picker to get a date
                        DatePicker (
                            "Date",
                            selection: $date,
                            displayedComponents: [.date]
                        )
                        .padding(.horizontal, 25)
                        
                        Spacer()
                    }
                }
                .backgroundBlockModifier()
                .padding(.bottom, K.Padding.verticalWidgetPadding)
                
                // amount
                Text("Amount").padding(.horizontal, K.Padding.horizontalTabPadding)
                
                VStack (alignment: .leading) {
                    // amount
                    HStack {
                        Text("$") // dollar
                            .padding(.leading, K.Padding.horizontalTabPadding)
                        TextField("Amount", text: $amount)
                            .keyboardType(.decimalPad)
                            .padding(.trailing, K.Padding.horizontalTabPadding)
                        Spacer()
                    }
                    // drop down for catefories
                    Picker("Category", selection: $selectedCategory) {
                        ForEach(K.Categories, id: \.self) { category in
                            Text(category)
                        }
                    }
                    .background(RoundedRectangle(cornerRadius: 16).fill(Color(.systemGroupedBackground)))
                    .padding(.horizontal, K.Padding.horizontalTabPadding)
                    
                }
                .backgroundBlockModifier()
                .padding(.bottom, K.Padding.verticalWidgetPadding)
                
                
                // report
                VStack {
                    HStack {
                        Text("Report").padding(.leading, K.Padding.horizontalTabPadding)
                        Spacer()
                        
                        // drop down for reports
                        Picker("Reports", selection: $selectedReport) {
                            ForEach(reports, id:\.self) { report in
                                Text(report)
                            }
                        }
                        .background(RoundedRectangle(cornerRadius: 16).fill(Color(.systemGroupedBackground)))
                        .padding(.trailing, K.Padding.horizontalTabPadding)
                    }
                }
                .backgroundBlockModifier()
                .padding(.bottom, K.Padding.verticalWidgetPadding)
                
                // Personal or business
                VStack {
                    Toggle(isOn: $isBusiness) {
                        Text("Business")
                    }
                    .padding(.horizontal, K.Padding.horizontalTabPadding)
                }
                .backgroundBlockModifier()
                .padding(.bottom, K.Padding.verticalWidgetPadding)
                
                // show reimbursable only if its a business expense
                if  (isBusiness) {
                    VStack {
                        Toggle(isOn: $isReimbursable) {
                            Text("Reimbursable")
                        }
                        .padding(.horizontal, K.Padding.horizontalTabPadding)
                    }
                    .backgroundBlockModifier()
                    .padding(.bottom, K.Padding.verticalWidgetPadding)
                }
                
                else {
                    Spacer()
                }
                                
                // confirm button
                HStack {
                    Spacer()
                    
                    Button (action: {
                        // if not business than cant be reimbursable
                        isReimbursable = isBusiness ? isReimbursable : false
                        // convert amount string to a float
                        let amountNumber: Float = Float(amount) ?? 0
                        // insert the new receipt
                        let newReceipt = Receipt(date: date, amount: [amountNumber], category: [selectedCategory], report: selectedReport, isBusiness: isBusiness, isReimbursable: isReimbursable)
                        context.insert(newReceipt)
                        showInfo = false
                    }, label: {
                        Text("Confirm")
                    })
                    .padding(.horizontal, 30)
                    .backgroundBlockModifier()
                    
                    Spacer()
                }
                
                
            }
            
        }
        .ignoresSafeArea()
        .background(Color(.systemGroupedBackground))
        
    }
}


#Preview {
    EditReceiptView(previewImage: nil, showInfo: .constant(true))
}
