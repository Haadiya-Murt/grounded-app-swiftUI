//
//  ProjectApp.swift
//  Project
//
//  Created by Student on 2026-03-02.
//

import SwiftUI
import SwiftData

@main
struct ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .font(.system(.body, design: .rounded))
                .modelContainer(for: Receipt.self)
        }
    }
}
