//
//  SideMenuOptionModel.swift
//  Project
//
//  Created by Student on 2026-03-02.
//

import Foundation

enum SideMenuOptionModel: Int, CaseIterable {
    case home
    case expenses
    case reports
    case taxes
    case analytics
    case budget
    case settings
    
    var title: String {
        switch self {
        case .home:
            return "Home"
        case .expenses:
            return "Expenses"
        case .reports:
            return "Reports"
        case .taxes:
            return "Taxes"
        case .analytics:
            return "Analytics"
        case .budget:
            return "Budget"
        case .settings:
            return "Settings"
        }
    }
    
    var SystemImageName: String {
        switch self {
        case .home:
            return "house"
        case .expenses:
            return "dollarsign.circle"
        case .reports:
            return "receipt"
        case .taxes:
            return "dollarsign.bank.building"
        case .analytics:
            return "chart.pie"
        case .budget:
            return "dollarsign.gauge.chart.leftthird.topthird.rightthird"
        case .settings:
            return "gearshape"
        }
    }
}

extension SideMenuOptionModel: Identifiable {
    var id: Int { self.rawValue }
}

enum SideMenuGroups: Int, CaseIterable {
    case main
    case spending
    case budgeting
    case other
    
    var section: String {
        switch self {
        case .main:
            return "Home"
        case .spending:
            return "Spending"
        case .budgeting:
            return "Budgeting"
        case .other:
            return "Other"
        }
    }
    
    var options: [SideMenuOptionModel] {
        switch self {
        case .main:
            return [.home]
        case .spending:
            return [.expenses, .reports, .taxes]
        case .budgeting:
            return [.analytics, .budget]
        case .other:
            return [.settings]
        }
    }
}

extension SideMenuGroups: Identifiable {
    var id: Int { self.rawValue }
}
