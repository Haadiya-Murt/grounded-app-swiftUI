//
//  ExpensesView.swift
//  Project
//
//  Created by Student on 2026-03-05.
//

import SwiftUI
import SwiftData

struct ExpensesView: View {
    
    // selected tab
    @Binding public var selectedTab: SideMenuOptionModel
    
    // selected image
    @State private var selectedImage: UIImage?
    // show edit receipt
    @State private var showEditReceipt: Bool = false
    // show add expense
    @State private var showAddExpense: Bool = false
    
    @Query(sort: \Receipt.date) private var receipts: [Receipt]
    @Environment(\.modelContext) private var context // how to access the model
    
    // select item in list
    @State private var expenseSelection: UUID?
    
    var body: some View {
    
        NavigationStack {
            
            // filters
            VStack () {
                
                VStack (alignment: .leading) {
                    Text("Filters").padding(.horizontal).padding(.vertical, 2)
                    // buttons in add expesnes
                    HStack {
                        Spacer()
                        // button for manual edit
                        Text("Type")
                        Spacer()
                        Text("Sort")
                        Spacer()
                        Text("From, To")
                        Spacer()
                    }.font(.callout)
                }
                .backgroundBlockModifier()

                // turn all the receipts into a list
//                List (receipts) { receipt in
//                    ExpenseItem(category: receipt.category, report: receipt.report, date: receipt.date, amount: receipt.amount)
//                }
                List {
                    ExpenseItem(
                        receipt: Receipt(date: .now, amount: [0.1], category: ["cat"], report: "rep", isBusiness: true, isReimbursable: true))
                }
                .padding(.vertical, -5)

                Spacer()
                
                // debug remove everything button
                Button( action: {
                    do {
                        try context.delete(model: Receipt.self)
                        try context.save()
                        // do it twice cuz its not working idk
                        try context.delete(model: Receipt.self)
                        try context.save()
                    } catch {
                        print("Failed to clear all receipt data")
                    }
                    print(receipts)
                }, label: {
                    Text("DEBUG - Delete everything\n Crashes preview :)")
                })
                .padding(.horizontal)
                .backgroundBlockModifier()
                
                AddReceiptButton(selectedImage: $selectedImage, showEditReceipt: $showEditReceipt, showAddExpense: $showAddExpense)
            }
            
            // navigate to edit receipt
            .navigationDestination(isPresented: $showEditReceipt) {
                EditReceiptView(previewImage: selectedImage, showInfo: $showEditReceipt)
            }
            
            // when tab changes hide the widget :
            .onChange(of: selectedTab) {
                showAddExpense = false
            }
            .onChange(of: showEditReceipt) {
                showAddExpense = false
            }
            .onTapGesture {
                showAddExpense = false
            }
            
        }
        
    }
}



#Preview {
    ExpensesView(selectedTab: .constant(SideMenuOptionModel.expenses))
}
