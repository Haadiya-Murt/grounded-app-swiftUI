//
//  BlockBackground.swift
//  Project
//
//  Created by Student on 2026-03-05.
//

import SwiftUI

//extension VStack {
//    func backgroundBlockModifier() -> some View {
//        self
//        .padding(.vertical)
//        .background(Color(.secondarySystemGroupedBackground))
////        .background(.opacity(K.Background.opacity))
//        .clipShape(RoundedRectangle(cornerRadius: 25))
//        .padding(.horizontal, K.Padding.horizontalTabPadding)
//    }
//}
//
//extension HStack {
//    func backgroundBlockModifier() -> some View {
//        self
//        .padding(.vertical)
//        .background(Color(.secondarySystemGroupedBackground))
////        .background(.opacity(K.Background.opacity))
//        .clipShape(RoundedRectangle(cornerRadius: 25))
//        .padding(.horizontal, K.Padding.horizontalTabPadding)
//    }
//}

extension View {
    func backgroundBlockModifier() -> some View {
        self
        .padding(.vertical)
        .background(Color(.secondarySystemGroupedBackground))
//        .background(.opacity(K.Background.opacity))
        .clipShape(RoundedRectangle(cornerRadius: 25))
        .padding(.horizontal, K.Padding.horizontalTabPadding)
    }
}

