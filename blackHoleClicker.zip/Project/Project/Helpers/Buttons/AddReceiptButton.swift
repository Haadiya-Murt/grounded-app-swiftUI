//
//  AddReceiptButton.swift
//  Project
//
//  Created by Student on 2026-03-05.
//

import SwiftUI

struct AddReceiptButton: View {
    
    // the selected image for edit receipt
    @Binding public var selectedImage: UIImage?
    // show edit reciept
    @Binding public var showEditReceipt: Bool
    // show widget
    @Binding public var showAddExpense: Bool
    
    
    var body: some View {
        
        VStack {
            // if showig than show the add expense widget
            if (showAddExpense) {
                AddExpenseWidget(selectedImage: $selectedImage, showEditReceipt: $showEditReceipt)
            }
            
            // show widget button
            Button (action: {
                showAddExpense.toggle()
            }, label: {
                VStack {
                    Text("+")
                        .foregroundStyle(.accent)
                        .bold()
                        .font(.largeTitle)
                }
                .font(.title)
                .bold()
                .padding()
                .background(.opacity(K.Background.opacity))
                .clipShape(Circle())
                .tint(.primary)
            })
            
        }
        
    }
}

#Preview {
    AddReceiptButton(selectedImage: .constant(UIImage()), showEditReceipt: .constant(false), showAddExpense: .constant(false))
}
