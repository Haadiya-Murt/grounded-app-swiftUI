//
//  Constants.swift
//  Project
//
//  Created by Student on 2026-03-05.
//

import Foundation

struct K {
    
    struct Padding {
        static let horizontalTabPadding: CGFloat = 15
        static let verticalWidgetPadding: CGFloat = 30
        static let underBackButtonPadding: CGFloat = 120
    }
    
    struct Background {
        static let opacity = 0.15
    }
    
    static let Categories = ["Other", "Meals and Entertainment", "Parking", "Gas"]
}
