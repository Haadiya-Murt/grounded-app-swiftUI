//
//  SideMenuRowView.swift
//  Project
//
//  Created by Student on 2026-03-02.
//

import SwiftUI

struct SideMenuRowView: View {
    
    let option: SideMenuOptionModel
    @Binding var selectedOption: SideMenuOptionModel
    
    // if its selected return that
    private var isSelected : Bool {
        return selectedOption == option
    }
    
    var body: some View {
        HStack {
            Image(systemName: option.SystemImageName)
                .imageScale(.small)
            Text(option.title)
            Spacer()
        }
        .padding(.leading)
        .foregroundStyle(isSelected ? Color.accentColor : .primary)
        .frame(width: 216, height: 44) // height was 44
//        .background(isSelected ? Color.accentColor.opacity(0.25) : .clear)
        .background(isSelected ? Color.secondary.opacity(0.25) : .clear)
        .clipShape(RoundedRectangle(cornerRadius: 10))
//        .padding(5)
    }
}

#Preview {
    SideMenuRowView(option: .home, selectedOption: .constant(.home))
}
