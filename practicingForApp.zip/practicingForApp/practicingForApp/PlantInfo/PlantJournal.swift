//
//  PlantJournal.swift
//  practicingForApp
//
//  Created by Student on 2026-05-12.
//

import SwiftUI
import SwiftData

struct PlantJournal: View {
	@Environment(\.modelContext) var context
	@Query var savedPlants: [UserPlant]
	@State var plantName: String
	
	
    var body: some View {
		ZStack {
			Color.mainPink
				.ignoresSafeArea()
			
			VStack {
				
				Text("\(plantName)'s Journal")
					.font(.custom("ChakraPetch-Bold", size: 35))
					.foregroundStyle(.yellingYellows)
					.padding()
					.background {
						Rectangle()
							.fill(.relativelyDeeperPink)
					}
				
		//		TextField("")
				
				
				
			}
		}
    }
}

#Preview {
	@Previewable @State var plantName = "Yanny"
	PlantJournal(plantName: plantName)
}
