//
//  Home.swift
//  Project
//
//  Created by Student on 2026-03-02.
//

import SwiftUI

struct HomeView: View {
    
    private let exampleHeaders: [String] = ["Add Expense",
                                            "Recent Spending",
                                            "Budget Warnings"]
    @State private var selectedImage: UIImage?
    @State private var showEditReceipt: Bool = false
    
    var body: some View {
        
        NavigationStack {
            
            VStack (alignment: .leading) {
                
                // account
//                HStack {
//                    VStack {
//                        SideMenuHeaderView()
//                    }
//                    Spacer()
//                }.padding(.vertical)
                
                //TODO: change headers
                Text(exampleHeaders[0]).padding(K.Padding.horizontalTabPadding)
                
                // the expense widget on the top
                AddExpenseWidget(selectedImage: $selectedImage, showEditReceipt: $showEditReceipt)
                
                Spacer()
            }
            // go to edit receipt view when the manual is pressed
            .navigationDestination(isPresented: $showEditReceipt) {
//                if let image = selectedImage {
                EditReceiptView(previewImage: selectedImage, showInfo: $showEditReceipt)
//                }
            }
            
        }
    }
}

#Preview {
    HomeView()
}
