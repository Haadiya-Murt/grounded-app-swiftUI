//
//  PlantOverview.swift
//  practicingForApp
//
//  Created by Student on 2026-05-12.
//

import SwiftUI
import SwiftData

enum FlowerOption: String, CaseIterable, Identifiable {
	case son1, son2, son3
	
	var id: Self { self }
	
	var matchingAsset: String {	self.rawValue }
	
	var matchingName: String {
		switch self {
		case .son1:
			return "Ornamental"
		case .son2:
			return "Edible"
		default:
			return "Ecological"
		}
	}
}


struct PlantOverview: View {
	
	// saving plants enabler
	@Environment(\.modelContext) var context
	@Environment(\.dismiss) private var dismiss
	@Query var savedPlants: [UserPlant]
	
	// plant info
	var spawnLocation: CGPoint?
	var editingPlant: UserPlant?
	@State var plantName: String = "Yanny"
	@State var plantSpecies: String = "Dandelion"
	@State var plantBday: Date = Date()
	@State var careDifficulty: Int = 1
	@Binding var selectedImage: UIImage?
	@State var selectedType: FlowerOption = .son1
	
	// popup stuff
	@State private var showPopup: Bool = false
	@State private var popupCategory: String = ""
	@State private var popupContent: String = ""

	
    var body: some View {
		
		NavigationStack() {
			ZStack {
				Color.mainPink
					.ignoresSafeArea()
				

				VStack {					
					ScrollView(.vertical, showsIndicators: true) {
						
						VStack {
							Spacer()
								.frame(maxHeight: 25)
							
							TextField("Insert plant name", text: $plantName)
								.font(.custom("ChakraPetch-SemiBold", size: 30))
								.frame(width: 300)
								.multilineTextAlignment(.center)
								.foregroundStyle(.yellingYellows)
								.padding()
								.background {
									Rectangle()
										.fill(.relativelyDeeperPink)
								}
		
							HStack {
								HStack {
									Text("Date planted:")
										.font(.custom("JetBrainsMono-Medium", size: 14))
										.foregroundStyle(.yellingYellows)
									DatePicker("Date planted", selection: $plantBday, displayedComponents: [.date])
										.labelsHidden()
									//	.font(.custom("JetBrainsMono-Medium", size: 14))
								}
								
								Spacer()
								
								Menu {
									ForEach(FlowerOption.allCases, id: \.self) { option in
										Button(action: {
											selectedType = option
										}) {
											Label(
												title: { Text(option.matchingName) },
												icon: {
													Image(option.matchingAsset)
													.foregroundStyle(.yellingYellows)
												}
											)
										}
									}
								} label: {
									HStack(spacing: 6) {
										Image(selectedType.matchingAsset)
											.resizable()
											.scaledToFit()
											.frame(width: 28)
											.foregroundStyle(.yellingYellows)
										
										Image(systemName: "chevron.down")
											.font(.system(size: 10, weight: .bold))
											.foregroundStyle(.yellingYellows)
									}
									.padding(.horizontal, 10)
									.frame(height: 36)
									.background(Rectangle().fill(.relativelyDeeperPink))
								}
							}
							.padding(.horizontal)
								
								
						//	}
							
							HStack(spacing: 20) {
								NavigationLink {
									CameraView(selectedImage: $selectedImage)
								} label: {
									
									if let plantImage = selectedImage {
										Image(uiImage: plantImage)
											.resizable()
											.scaledToFill()
											.frame(width: 150, height: 150)
											.clipped()
											.overlay {
												Image("borderDeco")
													.resizable()
													.scaledToFill()
													.frame(width: 180)
													.scaleEffect(x: -1)
													.shadow(radius: 0, x: 2, y: 3)
											}
									}
									else {
										Rectangle()
											.fill(.gray)
											.frame(width: 150, height: 150)
											.overlay {
												Image(systemName: "camera.fill")
													.font(.system(size: 30))
													.foregroundStyle(.white.opacity(0.3))
											}
									}
								}
								
								VStack {
									Text(plantSpecies.capitalized)
										.font(.custom("ChakraPetch-Bold", size: 25))
										.multilineTextAlignment(.center)
										.foregroundStyle(.yellingYellows)
									
									
									Text("Difficulty")
										.font(.custom("JetBrainsMono-MediumItalic", size: 20))
										.multilineTextAlignment(.center)
										.foregroundStyle(.yellingYellows)
										.padding(.bottom, 5)
									
									
									VStack(spacing: 5) {
										
										HStack(spacing: 4) {
											ForEach(1...3, id: \.self) { icon in
												Image(systemName:
														icon <= careDifficulty
													  ? "checkmark.square.fill"
													  : "checkmark.square"
												)
												.font(.system(size: 30))
												.foregroundStyle((careDifficulty >= icon) ? .yellingYellows : .relativelyDeeperPink)
											}
										}
										
										HStack(spacing: 4) {
											ForEach(4...5, id: \.self) { icon in
												Image(systemName:
														icon <= careDifficulty
													  ? "checkmark.square.fill"
													  : "checkmark.square"
												)
												.font(.system(size: 30))
												.foregroundStyle((careDifficulty >= icon) ? .yellingYellows : .relativelyDeeperPink)
											}
										}
									}
								}

							}
							.padding()
							
							VStack {
								categoryButton(title: "Description", content: PlantData.dandelionDescription)
								categoryButton(title: "Optimal Conditions", content: PlantData.dandelionConditions)
								categoryButton(title: "Dangers", content: PlantData.dandelionDangers)
								categoryButton(title: "Benefits", content: PlantData.dandelionBenefits)
							}
						}
						.padding(.horizontal)
					}
						Button (
							action: {
								if let plant = editingPlant {
									plant.name = plantName
									plant.datePlanted = plantBday
									plant.difficulty = careDifficulty
									plant.theLabel = selectedType.rawValue
									
									// also stolen from stack overflow
									if let image = selectedImage {
										plant.imageData = image.jpegData(compressionQuality: 0.8)
									}
									
								} else {
									let newPlant = UserPlant(
										name: plantName,
										journalEntry: nil,
										difficulty: careDifficulty,
										datePlanted: plantBday,
										theLabel: selectedType.rawValue,
										colourName: "white",
										xPosition: Double( spawnLocation?.x ?? 3000),
										yPosition: Double(spawnLocation?.y ?? 3000),
										imageData: selectedImage?.jpegData(compressionQuality: 0.8)
									)
									context.insert(newPlant)
								}
								selectedImage = nil
								
								dismiss()
								
							},
							label: {
								Text("Save \(plantName) to garden!")
									.font(.custom("ChakraPetch-Bold", size: 22))
									.foregroundStyle(.relativelyDeeperPink)
									.padding()
									.background(
										Rectangle()
											.fill(.yellingYellows)
									)
							}
						)
				}
			
				if showPopup {
					Color.black
						.opacity(0.4)
						.ignoresSafeArea()
						.onTapGesture {
							showPopup = false
						}
					
					VStack {
						
						HStack {
							Spacer()
							Button(action: {
								showPopup = false
							}) {
								Image(systemName: "xmark.circle.fill")
									.font(.title2)
									.foregroundColor(.lightGreen)
							}
						}
						.padding(.bottom, 5)
						
						VStack {
							Text(popupCategory)
								.multilineTextAlignment(.center)
								.font(.custom("ChakraPetch-Bold", size: 20))
								.foregroundStyle(.blackUp)
							
							ScrollView() {
								Text(popupContent)
									.font(.custom("JetBrainsMono-SemiBold", size: 15))
									.foregroundStyle(.blackUp)
									.padding()
									.background {
										Rectangle()
											.fill(.lightGreen)
									}
							}
						}
					}
					.padding()
					.frame(width: 300)
					.frame(maxHeight: 700)
					.background(
						Color.darkGreen
							.shadow(radius: 0, x: 2, y: 3)

					)
				}
			}
			.onAppear {
				if let plant = editingPlant {
					plantName = plant.name
					plantBday = plant.datePlanted
					careDifficulty = plant.difficulty
					
					if let savedEnum = FlowerOption(rawValue: plant.theLabel) {
								selectedType = savedEnum
					}
					
					if let data = plant.imageData {
								selectedImage = UIImage(data: data)
					}
				}
			}
			
		}
    }
	func categoryButton(title: String, content: String) -> some View {
		Button(action: {
			popupCategory = title
			popupContent = content
			withAnimation(.easeInOut) { showPopup = true }
		}) {
			Text(title)
				.font(.custom("ChakraPetch-SemiBold", size: 25))
				.foregroundStyle(.yellingYellows)
				.padding()
				.frame(maxWidth: .infinity)
				.background(Color.relativelyDeeperPink)
		}
	}
}

#Preview {
	PlantOverview(selectedImage: .constant(nil))
		.modelContainer(for: UserPlant.self, inMemory: true)
}

