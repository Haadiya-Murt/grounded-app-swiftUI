//
//  AddExpense.swift
//  Project
//
//  Created by Student on 2026-04-09.
//

import SwiftUI

struct AddExpenseWidget: View {
    
    @Binding public var selectedImage: UIImage?
    @Binding public var showEditReceipt: Bool
    
    var body: some View {
        VStack (alignment: .leading) {
            // buttons in add expesnes
            HStack (alignment: .center) {
                Spacer()
                // button for manual edit
                Button(action: {
                    selectedImage = nil
                    showEditReceipt = true
                }, label: {
                    VStack {
                        ExpenseButtonLabel(systemImageName: "pencil", description: "Manual")
                    }
                })
                // the other 2 buttons
                Spacer()
                AddPhotoButton(selectedImage: $selectedImage, showEditReceipt: $showEditReceipt)
                Spacer()
                TakePhotoButton(selectedImage: $selectedImage, showEditReceipt: $showEditReceipt)
                Spacer()
            }
        }
        .backgroundBlockModifier()
    }
}

#Preview {
    AddExpenseWidget(selectedImage: .constant(UIImage(systemName: "bell")), showEditReceipt: .constant(false))
}
