//
//  Receipt.swift
//  Project
//
//  Created by Student on 2026-04-13.
//

import Foundation
import SwiftData
import SwiftUI

@Model
class Receipt {
    var id: UUID = UUID()
    var date: Date
    var amount: [Float]
    var category: [String]
    var report: String
    var isBusiness: Bool
    var isReimbursable: Bool
    
    init (date: Date, amount: [Float], category: [String], report: String, isBusiness: Bool, isReimbursable: Bool) {
        self.date = date
        self.amount = amount
        self.category = category
        self.report = report
        self.isBusiness = isBusiness
        self.isReimbursable = isReimbursable
    }
    
}
