//
//  SavedPlantStuff.swift
//  practicingForApp
//
//  Created by Student on 2026-05-12.
//

import Foundation
import SwiftData
import SwiftUI

@Model
class UserPlant {
	var name: String
	var journalEntry: String? = nil
	var difficulty: Int
	var datePlanted: Date
	var theLabel: String
	var colourName: String
	var xPosition: Double
	var yPosition: Double
	
	// stolen from stack overflow
	@Attribute(.externalStorage) var imageData: Data?
	
	init(name: String, journalEntry: String?, difficulty: Int, datePlanted: Date, theLabel: String, colourName: String, xPosition: Double, yPosition: Double, imageData: Data? = nil) {
		self.name = name
		self.journalEntry = journalEntry
		self.difficulty = difficulty
		self.datePlanted = datePlanted
		self.theLabel = theLabel
		self.colourName = colourName
		self.xPosition = xPosition
		self.yPosition = yPosition
		self.imageData = imageData
	}
	
	var plantColor: Color {
			switch colourName {
			case "white": return .white
			case "yellingYellows": return .yellingYellows
			case "mainPink": return .mainPink
			case "oligotrophicBlue": return .oligotrophicBlue
			case "darkGreen": return .darkGreen
			case "orangeCreamsicle": return .orangeCreamsicle
			default: return .yellingYellows
			}
		}
	
}

struct PlantSpawn: Identifiable {
	let id = UUID()
	let location: CGPoint
}

