//
//  ContentView.swift
//  Project
//
//  Created by Student on 2026-03-02.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    
    @State private var showMenu : Bool = false
    @State private var selectedTab: SideMenuOptionModel = SideMenuOptionModel.home
    
    @Environment(\.modelContext) private var context // how to access the model
    
    var body: some View {
        // navigation stack to switch views
        NavigationStack {
            
            // zstack to stack sidebar on main menu
            ZStack {
                // display home view and side if showing
                TabView (selection: $selectedTab) {
                    HomeView().tag(SideMenuOptionModel.home)
                    ExpensesView(selectedTab: $selectedTab).tag(SideMenuOptionModel.expenses)
                    Text("Reports").tag(SideMenuOptionModel.reports)
                    Text("Taxes").tag(SideMenuOptionModel.taxes)
                    Text("Analytics").tag(SideMenuOptionModel.analytics)
                    Text("Budget").tag(SideMenuOptionModel.budget)
                    Text("Settings").tag(SideMenuOptionModel.settings)
                }
                //.padding(.horizontal, K.Padding.horizontalTabPadding)
                .padding(.top, showMenu ? 54 : 0)
                .tabViewStyle(.page(indexDisplayMode: .never)) // hide tab view
                //.background(UIColor.secondarySystemBackground)
                .background(Color(.systemGroupedBackground))
                
                SideMenuView(isShowing: $showMenu, selectedTab: $selectedTab)
            }
            
            // top toolbar
            .toolbar(showMenu ? .hidden : .visible, for: .navigationBar)
            .navigationTitle(selectedTab.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    if (!showMenu) {
                        Button(action: {
                            showMenu.toggle()
                        }, label: {
                            Image(systemName: "line.3.horizontal")
                        })
                    }
                }
            }

        }
        
    }
}

#Preview {
    ContentView().font(.system(.body, design: .rounded))
}
