//
//  TakePhotoButton.swift
//  Project
//
//  Created by Student on 2026-03-05.
//

import SwiftUI

struct TakePhotoButton: View {
    
    // controls whether the camera sheet is shown
    @State private var showingCamera: Bool = false
    // stores the actual UIImage after it has been loaded
    @Binding public var selectedImage: UIImage?
    // controls navigation to the info view, public so other navs can access it
    @Binding public var showEditReceipt: Bool
    
    var body: some View {
        // camera button
        Button(action: {
            showingCamera = true
        }) {
            VStack {
                ExpenseButtonLabel(systemImageName: "camera", description: "Take Photo")
            }
        }
        // shows the camera view as a sheet if showingCamera
        .sheet(isPresented: $showingCamera) {
            // pass binding so CameraView can update selectedImage
            CameraView(image: $selectedImage)
        }
        
        // runs whenever selectedItem changes
        .onChange(of: selectedImage) {
            // show receipt when image changes
            showEditReceipt = true
        }
    }
}

#Preview {
    TakePhotoButton(selectedImage: .constant(UIImage(systemName: "bell")), showEditReceipt: .constant(true))
}
