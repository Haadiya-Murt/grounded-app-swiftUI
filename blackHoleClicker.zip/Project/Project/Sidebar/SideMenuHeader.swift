//
//  SideMenuHeaderView.swift
//  Project
//
//  Created by Student on 2026-03-02.
//

import SwiftUI

struct SideMenuHeader: View {
            
    var body: some View {
        // logo and text
        HStack {
            Image("Logo").resizable().frame(width: 70, height: 70)
            Text("Budget Scanner")
                .font(.title3)
        }
        .foregroundStyle(.accent)
        .padding(.horizontal)
        .bold()
        
//        HStack {
//            // image
//            Image(systemName: "person.circle.fill")
//                .imageScale(.large)
//                .foregroundStyle(.white)
//                .frame(width: 48, height: 48)
//                .background(Color.accentColor)
//                .clipShape(RoundedRectangle(cornerRadius: 10))
//                .padding(.vertical)
//
//            // text
//            VStack (alignment: .leading, spacing: 6) {
//                Text("Random Person")
//                Text("randomEmail@gmail.com").font(.footnote).tint(.gray)
//            }
//        }
    }
}

#Preview {
    SideMenuHeader()
}
